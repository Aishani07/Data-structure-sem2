# ============================================================
# Sorting Performance Analyzer (SPA)
# Course: Basics of Data Structures (ETCCBD201)
# Assignment: Lab Assignment-3 – Sorting Algorithms
# Name: Aishani Das
# Roll No.: 2501840003
# ============================================================

import time
import random
import copy

# ============================================================
# TASK 1: SORTING ALGORITHM IMPLEMENTATIONS
# ============================================================

def insertion_sort(arr):
    """
    Insertion Sort Implementation
    - Time Complexity: O(n^2) worst/average, O(n) best (already sorted)
    - Space Complexity: O(1) — In-place
    - Stability: Stable
    """
    arr = arr[:]  # work on a copy
    n = len(arr)
    for i in range(1, n):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr


def merge(left, right):
    """Helper function for Merge Sort: merges two sorted lists."""
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:   # <= ensures stability
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result


def merge_sort(arr):
    """
    Merge Sort Implementation
    - Time Complexity: O(n log n) — all cases
    - Space Complexity: O(n) — Out-of-place (uses extra space)
    - Stability: Stable
    """
    if len(arr) <= 1:
        return arr[:]
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)


def partition(arr, low, high):
    """Lomuto partition scheme — pivot is last element."""
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def quick_sort(arr, low=None, high=None):
    """
    Quick Sort Implementation
    - Pivot strategy: Last element (Lomuto partition)
    - Time Complexity: O(n log n) average, O(n^2) worst (sorted input + last pivot)
    - Space Complexity: O(log n) stack space — essentially In-place
    - Stability: NOT stable (in typical implementation)
    Note: Python's default recursion limit can be hit on sorted/reverse-sorted
    large inputs with last-element pivot (worst case). We increase the limit
    and use an iterative stack-based approach to handle this gracefully.
    """
    import sys
    sys.setrecursionlimit(50000)

    if low is None:
        arr = arr[:]  # work on a copy at top-level call
        _quick_sort_iterative(arr, 0, len(arr) - 1)
        return arr
    _quick_sort_iterative(arr, low, high)


def _quick_sort_iterative(arr, low, high):
    """Iterative Quick Sort using an explicit stack to avoid Python recursion limits."""
    stack = []
    stack.append((low, high))
    while stack:
        lo, hi = stack.pop()
        if lo < hi:
            pi = partition(arr, lo, hi)
            stack.append((lo, pi - 1))
            stack.append((pi + 1, hi))


# ============================================================
# TASK 1: CORRECTNESS CHECK
# ============================================================

def correctness_check():
    test_input = [5, 2, 9, 1, 5, 6]
    expected   = [1, 2, 5, 5, 6, 9]

    print("=" * 60)
    print("CORRECTNESS CHECK")
    print("=" * 60)
    print(f"Input:    {test_input}")
    print(f"Expected: {expected}")
    print()

    results = {
        "Insertion Sort": insertion_sort(test_input[:]),
        "Merge Sort"    : merge_sort(test_input[:]),
        "Quick Sort"    : quick_sort(test_input[:]),
    }

    all_pass = True
    for name, result in results.items():
        status = "PASS" if result == expected else "FAIL"
        if status == "FAIL":
            all_pass = False
        print(f"  {name:<20}: {result}  [{status}]")

    print()
    if all_pass:
        print("All algorithms produce correct output.")
    else:
        print("WARNING: One or more algorithms failed the correctness check!")
    print()


# ============================================================
# TASK 2: TIMING UTILITY
# ============================================================

def measure_time(sort_func, arr):
    """
    Measures execution time of a sorting function on a given list.
    - Makes a copy so the original array is unchanged.
    - Returns time in milliseconds.
    """
    arr_copy = copy.deepcopy(arr)
    start = time.perf_counter()
    sort_func(arr_copy)
    end = time.perf_counter()
    return (end - start) * 1000  # convert to milliseconds


# ============================================================
# TASK 2: DATASET GENERATOR
# ============================================================

RANDOM_SEED = 42
SIZES = [1000, 5000, 10000]

def generate_datasets():
    """
    Generates 9 datasets:
    - 3 types (random, sorted, reverse-sorted)
    - 3 sizes (1000, 5000, 10000)
    Uses integers in range 1 to 100000.
    """
    datasets = {}
    random.seed(RANDOM_SEED)
    for size in SIZES:
        rand_list    = [random.randint(1, 100000) for _ in range(size)]
        sorted_list  = sorted(rand_list)
        reverse_list = sorted_list[::-1]
        datasets[size] = {
            "random"  : rand_list,
            "sorted"  : sorted_list,
            "reverse" : reverse_list,
        }
    return datasets


# ============================================================
# TASK 2: RUN EXPERIMENTS
# ============================================================

def run_experiments(datasets):
    """
    Runs all 27 experiments (3 sizes × 3 input types × 3 algorithms).
    Returns results as a nested dict.
    """
    algorithms = {
        "Insertion Sort": insertion_sort,
        "Merge Sort"    : merge_sort,
        "Quick Sort"    : quick_sort,
    }
    results = {}

    for size in SIZES:
        results[size] = {}
        for input_type, data in datasets[size].items():
            results[size][input_type] = {}
            for algo_name, algo_func in algorithms.items():
                t = measure_time(algo_func, data)
                results[size][input_type][algo_name] = round(t, 4)

    return results


# ============================================================
# PRINT RESULTS TABLE
# ============================================================

def print_results_table(results):
    col_w = 17
    header_line = f"{'Size':<8} {'Input Type':<14} {'Insertion Sort':>{col_w}} {'Merge Sort':>{col_w}} {'Quick Sort':>{col_w}}"
    sep = "-" * len(header_line)

    print("=" * 60)
    print("PERFORMANCE RESULTS (times in milliseconds)")
    print("=" * 60)
    print(header_line)
    print(sep)

    for size in SIZES:
        for input_type in ["random", "sorted", "reverse"]:
            r = results[size][input_type]
            print(
                f"{size:<8} {input_type:<14}"
                f" {r['Insertion Sort']:>{col_w}.4f}"
                f" {r['Merge Sort']:>{col_w}.4f}"
                f" {r['Quick Sort']:>{col_w}.4f}"
            )
        print(sep)
    print()


# ============================================================
# MAIN RUNNER
# ============================================================

if __name__ == "__main__":
    print()
    print("=" * 60)
    print("  SORTING PERFORMANCE ANALYZER (SPA)")
    print("  Basics of Data Structures — ETCCBD201")
    print("  Name   : Aishani Das")
    print("  Roll No: 2501840003")
    print("=" * 60)
    print()

    # Step 1 — Correctness Check
    correctness_check()

    # Step 2 — Generate datasets
    print("Generating datasets (random seed = 42) ...")
    datasets = generate_datasets()
    print("Datasets ready.\n")

    # Step 3 — Run all experiments
    print("Running experiments (27 total) ...")
    results = run_experiments(datasets)
    print("Experiments complete.\n")

    # Step 4 — Print results
    print_results_table(results)

    print("NOTE: Insertion Sort may be very slow or cause recursion issues")
    print("      on large sorted/reverse-sorted inputs due to O(n^2) complexity.")
    print("      Quick Sort also degrades to O(n^2) on sorted inputs with last-")
    print("      element pivot strategy (worst-case scenario).")
    print()
    print("Results saved to output.txt (redirect with: python spa_sorting.py > output.txt)")
    print("=" * 60)
