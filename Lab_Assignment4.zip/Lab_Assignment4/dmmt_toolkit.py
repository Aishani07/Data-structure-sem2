# -----------------------------
# Binary Search Tree (BST)
# -----------------------------

class BSTNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    # Insert
    def insert(self, key):
        self.root = self._insert(self.root, key)

    def _insert(self, node, key):
        if node is None:
            return BSTNode(key)

        if key < node.key:
            node.left = self._insert(node.left, key)
        else:
            node.right = self._insert(node.right, key)

        return node

    # Search
    def search(self, key):
        return self._search(self.root, key)

    def _search(self, node, key):
        if node is None:
            return False

        if node.key == key:
            return True

        if key < node.key:
            return self._search(node.left, key)

        return self._search(node.right, key)

    # Inorder Traversal
    def inorder(self):
        result = []
        self._inorder(self.root, result)
        return result

    def _inorder(self, node, result):
        if node:
            self._inorder(node.left, result)
            result.append(node.key)
            self._inorder(node.right, result)

    # Find Minimum Value Node
    def min_value_node(self, node):
        current = node

        while current.left is not None:
            current = current.left

        return current

    # Delete
    def delete(self, key):
        self.root = self._delete(self.root, key)

    def _delete(self, node, key):

        if node is None:
            return node

        if key < node.key:
            node.left = self._delete(node.left, key)

        elif key > node.key:
            node.right = self._delete(node.right, key)

        else:

            # Case 1: No Child
            if node.left is None and node.right is None:
                return None

            # Case 2: One Child
            elif node.left is None:
                return node.right

            elif node.right is None:
                return node.left

            # Case 3: Two Children
            temp = self.min_value_node(node.right)
            node.key = temp.key
            node.right = self._delete(node.right, temp.key)

        return node


# -----------------------------
# Graph using Adjacency List
# -----------------------------

class Graph:
    def __init__(self):
        self.graph = {}

    # Add Edge
    def add_edge(self, u, v, w):
        if u not in self.graph:
            self.graph[u] = []

        self.graph[u].append((v, w))

    # Print Graph
    def print_graph(self):
        print("\nAdjacency List:")
        for node in self.graph:
            print(node, "->", self.graph[node])

    # BFS
    def bfs(self, start):
        visited = set()
        queue = [start]

        visited.add(start)

        print("\nBFS Traversal:")

        while queue:
            node = queue.pop(0)
            print(node, end=" ")

            for neighbor, weight in self.graph.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

    # DFS
    def dfs(self, start):
        visited = set()

        print("\nDFS Traversal:")

        self._dfs_recursive(start, visited)

    def _dfs_recursive(self, node, visited):
        visited.add(node)

        print(node, end=" ")

        for neighbor, weight in self.graph.get(node, []):
            if neighbor not in visited:
                self._dfs_recursive(neighbor, visited)


# -----------------------------
# Main Program
# -----------------------------

print("===== BINARY SEARCH TREE =====")

bst = BST()

# Insert Elements
elements = [50, 30, 70, 20, 40, 60, 80]

for element in elements:
    bst.insert(element)

print("\nInorder Traversal After Insertion:")
print(bst.inorder())

# Search
print("\nSearch 20:", bst.search(20))
print("Search 90:", bst.search(90))

# Delete Leaf Node
print("\nDeleting Leaf Node: 20")
bst.delete(20)

print("Inorder Traversal:")
print(bst.inorder())

# Create One Child Case
bst.insert(65)

print("\nDeleting Node With One Child: 60")
bst.delete(60)

print("Inorder Traversal:")
print(bst.inorder())

# Delete Node With Two Children
print("\nDeleting Node With Two Children: 30")
bst.delete(30)

print("Inorder Traversal:")
print(bst.inorder())


# -----------------------------
# GRAPH OPERATIONS
# -----------------------------

print("\n\n===== GRAPH TRAVERSALS =====")

g = Graph()

# Add Edges
g.add_edge('A', 'B', 2)
g.add_edge('A', 'C', 4)
g.add_edge('B', 'D', 7)
g.add_edge('B', 'E', 3)
g.add_edge('C', 'E', 1)
g.add_edge('D', 'F', 5)
g.add_edge('E', 'D', 2)
g.add_edge('E', 'F', 6)
g.add_edge('C', 'F', 8)

# Print Graph
g.print_graph()

# BFS
g.bfs('A')

# DFS
g.dfs('A')

