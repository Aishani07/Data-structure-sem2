class SocialGraph:

    def __init__(self):
        self.graph = {}

    # Add User Node
    def add_user(self, user_id):

        if user_id not in self.graph:
            self.graph[user_id] = []

    # Add Friendship
    def add_friendship(self, user1, user2):

        if user1 not in self.graph or user2 not in self.graph:
            print("One or both users do not exist.")
            return

        if user2 not in self.graph[user1]:
            self.graph[user1].append(user2)

        if user1 not in self.graph[user2]:
            self.graph[user2].append(user1)

        print(f"Friendship added between {user1} and {user2}")

    # Remove Friendship
    def remove_friendship(self, user1, user2):

        if user1 in self.graph and user2 in self.graph[user1]:
            self.graph[user1].remove(user2)

        if user2 in self.graph and user1 in self.graph[user2]:
            self.graph[user2].remove(user1)

        print(f"Friendship removed between {user1} and {user2}")

    # Get Friends
    def get_friends(self, user_id):

        if user_id not in self.graph:
            print("User not found.")
            return []

        return self.graph[user_id]

    # Print Friend List
    def display_friends(self, user_id):

        friends = self.get_friends(user_id)

        print(f"\nFriends of {user_id}: {friends}")