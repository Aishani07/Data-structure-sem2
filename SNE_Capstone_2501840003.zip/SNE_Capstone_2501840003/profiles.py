class UserProfiles:

    def __init__(self):
        self.users = {}

    # Add User
    def add_user(self, user_id, name, age, interests):

        if user_id in self.users:
            print(f"User ID {user_id} already exists.")
            return

        self.users[user_id] = {
            "name": name,
            "age": age,
            "interests": interests
        }

        print(f"User {user_id} added successfully.")

    # Get User Profile
    def get_user_profile(self, user_id):

        if user_id not in self.users:
            print("User not found.")
            return None

        return self.users[user_id]

    # Update User Profile
    def update_user_profile(self, user_id, new_details):

        if user_id not in self.users:
            print("User not found.")
            return

        self.users[user_id].update(new_details)

        print(f"User {user_id} updated successfully.")

    # Display User Profile
    def display_user(self, user_id):

        user = self.get_user_profile(user_id)

        if user:
            print(f"\nUser ID: {user_id}")
            print(f"Name: {user['name']}")
            print(f"Age: {user['age']}")
            print(f"Interests: {', '.join(user['interests'])}")