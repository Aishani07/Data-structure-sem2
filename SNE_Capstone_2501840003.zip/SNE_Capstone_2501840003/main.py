from profiles import UserProfiles
from network_graph import SocialGraph
from algorithms import bfs_shortest_path, dfs_depth, friend_suggestions


profiles = UserProfiles()
network = SocialGraph()

# -----------------------------
# Add Sample Users
# -----------------------------

sample_users = [

    ("u1", "Aman", 21, ["sports", "music", "tech"]),
    ("u2", "Riya", 22, ["movies", "music", "travel"]),
    ("u3", "Karan", 20, ["tech", "gaming", "sports"]),
    ("u4", "Sneha", 23, ["reading", "travel", "music"]),
    ("u5", "Rahul", 24, ["gaming", "tech", "movies"]),
    ("u6", "Priya", 22, ["sports", "fitness", "travel"])
]

for user in sample_users:

    profiles.add_user(user[0], user[1], user[2], user[3])

    network.add_user(user[0])

# -----------------------------
# Update Profiles
# -----------------------------

profiles.update_user_profile("u2", {"age": 23})
profiles.update_user_profile("u5", {"name": "Rahul Sharma"})

# -----------------------------
# Display Profiles
# -----------------------------

profiles.display_user("u1")
profiles.display_user("u2")
profiles.display_user("u3")

# -----------------------------
# Add Friendships
# -----------------------------

network.add_friendship("u1", "u2")
network.add_friendship("u1", "u3")
network.add_friendship("u2", "u4")
network.add_friendship("u3", "u5")
network.add_friendship("u4", "u5")
network.add_friendship("u5", "u6")
network.add_friendship("u2", "u6")
network.add_friendship("u3", "u6")

# -----------------------------
# Remove Friendship
# -----------------------------

network.remove_friendship("u2", "u6")

# -----------------------------
# Display Friends
# -----------------------------

network.display_friends("u1")
network.display_friends("u3")

# -----------------------------
# BFS Shortest Path
# -----------------------------

print("\nShortest Path from u1 to u5:")
print(bfs_shortest_path(network.graph, "u1", "u5"))

print("\nShortest Path from u1 to u6:")
print(bfs_shortest_path(network.graph, "u1", "u6"))

# -----------------------------
# DFS Depth Search
# -----------------------------

print("\nDFS Depth Search from u1 with depth 2:")
print(dfs_depth(network.graph, "u1", 2))

print("\nDFS Depth Search from u1 with depth 3:")
print(dfs_depth(network.graph, "u1", 3))

# -----------------------------
# Friend Suggestions
# -----------------------------

print("\nTop Friend Suggestions for u1:")

suggestions = friend_suggestions("u1", profiles.users, network.graph)

for user, score in suggestions:
    print(user, "Score:", score)