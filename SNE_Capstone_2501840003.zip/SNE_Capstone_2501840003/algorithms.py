from collections import deque
from sorting import insertion_sort


# BFS Shortest Path
def bfs_shortest_path(graph, start, goal):

    visited = set()
    queue = deque([[start]])

    if start == goal:
        return [start]

    while queue:

        path = queue.popleft()
        node = path[-1]

        if node not in visited:

            neighbors = graph[node]

            for neighbor in neighbors:

                new_path = list(path)
                new_path.append(neighbor)

                if neighbor == goal:
                    return new_path

                queue.append(new_path)

            visited.add(node)

    return []


# DFS Depth Limited
def dfs_depth(graph, start, depth, visited=None):

    if visited is None:
        visited = set()

    visited.add(start)

    if depth == 0:
        return visited

    for neighbor in graph[start]:

        if neighbor not in visited:
            dfs_depth(graph, neighbor, depth - 1, visited)

    return visited


# Friend Suggestions
def friend_suggestions(user_id, profiles, graph):

    user_interests = set(profiles[user_id]["interests"])

    suggestions = []

    for other_user in profiles:

        if other_user != user_id and other_user not in graph[user_id]:

            other_interests = set(profiles[other_user]["interests"])

            common = len(user_interests.intersection(other_interests))

            suggestions.append((other_user, common))

    sorted_suggestions = insertion_sort(suggestions)

    return sorted_suggestions[:5]